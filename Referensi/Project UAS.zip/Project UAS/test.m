cam=webcam(1);
preview(cam);
savepath = 'C:\Users\Denny Febry\Dropbox\Project AI';
for idx = 1:60
    img = snapshot(cam);
    image(img);
    gray = rgb2gray(img);
end
figure,imshow(gray);
clear cam;
fullname=fullfile(savepath,'namafile.png');
imwrite(gray,fullname);

I=imread('namafile.png');
J=imresize(I,0.05);

BW=im2bw(J,0.5);
imshowpair(BW,J,'montage');

fullname2=fullfile(savepath,'namafile2.png');
imwrite(J,fullname2);

a=im2double(imread('namafile.png'));
b=reshape(a,1,2304);

c=b';
contoh=c;

A=sim(net,contoh);
nama = {'a','e','i','o','u'};
mak=0;
for i=1:5
        if(mak<A(i)*10)
            mak=i;
        end
end

nama(mak)