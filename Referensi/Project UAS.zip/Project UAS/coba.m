function varargout = coba(varargin)
% COBA MATLAB code for coba.fig
%      COBA, by itself, creates a new COBA or raises the existing
%      singleton*.
%
%      H = COBA returns the handle to a new COBA or the handle to
%      the existing singleton*.
%
%      COBA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COBA.M with the given input arguments.
%
%      COBA('Property','Value',...) creates a new COBA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before coba_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to coba_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help coba

% Last Modified by GUIDE v2.5 05-Jun-2017 22:00:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @coba_OpeningFcn, ...
                   'gui_OutputFcn',  @coba_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before coba is made visible.
function coba_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to coba (see VARARGIN)

% Choose default command line output for coba
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% UIWAIT makes coba wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = coba_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in camera.
function camera_Callback(hObject, eventdata, handles)
% hObject    handle to camera (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vid=videoinput('winvideo', 1, 'MJPG_640x480');
vid.FramesPerTrigger = 1;
vid.ReturnedColorspace = 'rgb';
triggerconfig(vid, 'manual');
vidRes = get(vid,'VideoResolution');
imWidth = vidRes(1);
imHeight = vidRes(2);
nBands = get(vid, 'NumberOfBands');
hImage = image(zeros(imHeight, imWidth, nBands), 'parent', handles.aPreview);
preview(vid,hImage);
handles.vid = vid;
guidata(hObject, handles);


% --- Executes on button press in capture.
function capture_Callback(hObject, eventdata, handles)
% hObject    handle to capture (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isfield(handles, 'vid')
    warndlg('Camera belum siap!');
    return;
end
vid = handles.vid;
vid.FramesPerTrigger = 1;
vid.ReturnedColorspace = 'rgb';
triggerconfig(vid, 'manual');
vidRes = get(vid, 'VideoResolution');
imWidth = vidRes(1);
imHeight = vidRes(2);
nBands = get(vid, 'NumberOfBands');
hImage = image(zeros(imHeight, imWidth, nBands), 'parent', handles.aPreview);
preview(vid, hImage);

start(vid);
pause(1);
trigger(vid);
stoppreview(vid);
capt1 = getdata(vid);
imwrite(capt1, 'captured.png');
warndlg('Berhasil!');


% --- Executes on button press in proses.
function proses_Callback(hObject, eventdata, handles)
% hObject    handle to proses (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
b1=('a.png');
b2=('e.png');
d1=('i.png');
d2=('o.png');
j1=('u.png');

ib1=im2double(imread(b1));
ib2=im2double(imread(b2));
id1=im2double(imread(d1));
id2=im2double(imread(d2));
ir1=im2double(imread(j1));


r1=reshape(ib1,1,2304);
r2=reshape(ib2,1,2304);
r3=reshape(id1,1,2304);
r4=reshape(id2,1,2304);
r5=reshape(ir1,1,2304);


k1=r1';
k2=r2';
k3=r3';
k4=r4';
k5=r5';


%training data

citra_training=[k1,k2,k3,k4,k5];
target=eye(5);
[R,Q]=size(citra_training);
[S2,O]=size(target);

S1=10;
net=newff (minmax(citra_training),[S1,S2],{'logsig','logsig'},'traingdx');
net.LW{2,1}=net.LW{2,1}*0.01;
net.b{2}=net.b{2}*0.01;

net.performFcn='sse';
net.trainParam.goal=0.01;
net.trainParam.show=20;
net.trainParam.epochs=5000;
net.trainParam.mc=0.95;

P=citra_training;
T=target;

[net,tr]=train(net,P,T);

I=imread('namafile.png');
J=imresize(I,0.05);

BW=im2bw(J,0.5);
imshowpair(BW,J,'montage');

fullname2=fullfile(savepath,'namafile2.png');
imwrite(J,fullname2);

a=im2double(imread('namafile.png'));
b=reshape(a,1,2304);

c=b';
contoh=c;

A=sim(net,contoh);
nama = {'a','e','i','o','u'};
mak=0;
for i=1:5
        if(mak<A(i)*15)
            mak=i;
        end
end

nama(mak)
